# Personalização do personagem (Cat Launcher)

Tela: `launcher/src/cat_customize.rs` (aberta pelo botão **Personalizar** da Home; `HORIZON_LAUNCHER_PAGE=customize` abre nela para capturas).
Lógica: `launcher/src/customize.rs` (testes em `launcher/src/customize/tests.rs`).

- Categorias: camisas, calças, shorts, calçados, acessórios, chapéus e capas, mais a skin completa importada (Importar Skin).
- Importar: seletor de arquivos; o PNG é validado (skin 64x64 ou 64x32; capa 64x32, 22x17 ou múltiplos; a peça precisa ter pixels na região dela) e guardado em `<dados>/customize/imports/`. Fica na lista depois de reiniciar.
- Salvar Alterações grava `outfit.json`, a skin completa montada (`skin.png`) e a capa (`cape.png`) em `<dados>/customize/`. O jogo as recebe pelas variáveis `HORIZON_OFFLINE_SKIN`, `HORIZON_OFFLINE_SKIN_MODEL` e `HORIZON_OFFLINE_CAPE` (`backend::client_command`).
- Restaurar Padrão volta à aparência original e apaga `skin.png` e `cape.png`; os arquivos importados continuam na lista.
- Servidores oficiais mostram a skin da conta Microsoft; use "Exportar skin completa (.png)" (aba Seleções) e envie à conta. Capas próprias não podem ser enviadas à conta Microsoft.
