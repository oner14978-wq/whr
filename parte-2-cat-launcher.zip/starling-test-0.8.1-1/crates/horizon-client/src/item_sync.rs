//! Item stacks on the wire (`ItemStack.OPTIONAL_STREAM_CODEC`): the component
//! patch read back as vanilla's `components` compound, so the decoder the saved
//! and command item NBT use fills every field. Both sides use it: a client for
//! what its server sends, a server for a creative client's
//! `SetCreativeModeSlot`. The other direction is `lan::guest::stack_to_network`.
use crate::items::ItemStack;
use horizon_core::nbt::Tag;
use horizon_protocol::buf::{Codec, Reader};
use horizon_protocol::item::{Component, Profile, Stack, Template, component};
use horizon_protocol::registry::{Builtin, Dynamic};
use std::sync::Arc;

pub(crate) mod attribute_modifiers;
pub(crate) mod kinetic;

/// A stack from the wire: its item by the built-in registry's id, its
/// components by the synced registries' (enchantments, trims).
pub fn from_network(s: &Stack, builtin: &Builtin, synced: &Dynamic) -> ItemStack {
    let mut out = ItemStack {
        item: item_name(builtin, s.item),
        count: s.count.max(0) as u32,
        damage: 0,
        extra: None,
    };
    let components = components_tag(s, builtin, synced);
    let (damage, data) = crate::item_data::decode_components(components.as_ref());
    out.damage = damage;
    if let Some(data) = data {
        *out.data_mut() = *data;
    }
    out.tidy();
    // What it decoded to, to send the server's own patch back if that holds.
    if let Some(patch) = &s.wire.0 {
        let decoded = out.clone();
        out.data_mut().wire = crate::item_data::Wire::new(decoded, patch.clone());
    }
    out
}

/// `LivingEntity.canGlideUsing`: `stack`, worn in equipment slot `slot`
/// (`EquipmentSlot`'s serialized name), has `glider`, its `equippable` slot is
/// that one, and its next damage won't break it. Any item can glide this way:
/// a server or a command may give a chestplate both components.
pub fn can_glide_using(stack: &ItemStack, slot: &str, items: &crate::items::Items) -> bool {
    let Some(info) = items.get(&stack.item) else {
        return false;
    };
    if info.max_damage != 0 && stack.damage + 1 >= info.max_damage {
        return false;
    }
    // Asked every tick for each slot: a stack with no components of its own
    // answers from its item, with nothing to copy or decode.
    if stack.data().is_none() {
        return info.glider && info.equip_slot.as_deref() == Some(slot);
    }
    let (glider, equip_slot) = glider_and_slot(stack, info.glider, info.equip_slot.clone());
    glider && equip_slot.as_deref() == Some(slot)
}

/// The effective equippable slot after the stack's component patch.
pub fn equippable_slot(stack: &ItemStack, items: &crate::items::Items) -> Option<String> {
    let info = items.get(&stack.item)?;
    glider_and_slot(stack, info.glider, info.equip_slot.clone()).1
}

/// The `glider` and `equippable` slot `stack` has, from its item's own: the
/// saved components (a command's, a save's) patch them, then the server's
/// patch, which may also remove them and whose `equippable` isn't kept as a
/// saved component.
fn glider_and_slot(
    stack: &ItemStack,
    mut glider: bool,
    mut slot: Option<String>,
) -> (bool, Option<String>) {
    let Some(data) = stack.data() else {
        return (glider, slot);
    };
    if data.other("!minecraft:glider").is_some() {
        glider = false;
    } else if data.other("minecraft:glider").is_some() {
        glider = true;
    }
    if data.other("!minecraft:equippable").is_some() {
        slot = None;
    } else if let Some(equippable) = data.other("minecraft:equippable") {
        slot = match equippable.get("slot") {
            Some(Tag::String(s)) => Some(s.to_string_lossy()),
            _ => None,
        };
    }
    let Some((added, removed)) = data
        .wire
        .patch()
        .and_then(|p| horizon_protocol::item::WirePatch::decode(p).ok())
    else {
        return (glider, slot);
    };
    if removed.contains(&component::GLIDER) {
        glider = false;
    }
    if removed.contains(&component::EQUIPPABLE) {
        slot = None;
    }
    for (kind, c) in &added {
        match (*kind, c) {
            (component::GLIDER, _) => glider = true,
            // Equippable.STREAM_CODEC starts with its slot's id (EquipmentSlot.getId).
            (component::EQUIPPABLE, Component::Raw(bytes)) => {
                slot = Reader::new(bytes)
                    .varint()
                    .ok()
                    .and_then(equipment_slot_name)
                    .map(str::to_owned);
            }
            _ => {}
        }
    }
    (glider, slot)
}

/// The `consumable` and `blocks_attacks` the server's patch adds to `stack`,
/// components this client otherwise reads past (a server's sword made to
/// block, `diamond_sword[blocks_attacks={},consumable={...}]`): the added
/// consumable's `Consumable.consumeTicks` (`consumeSeconds * 20`), and
/// whether `blocks_attacks` is added.
pub fn patched_use(stack: &ItemStack) -> (Option<i32>, bool) {
    let Some((added, _)) = stack
        .data()
        .and_then(|d| d.wire.patch())
        .and_then(|p| horizon_protocol::item::WirePatch::decode(p).ok())
    else {
        return (None, false);
    };
    let mut out = (None, false);
    for (kind, c) in &added {
        match (*kind, c) {
            (component::CONSUMABLE, Component::Raw(bytes)) => {
                out.0 = Reader::new(bytes)
                    .f32()
                    .ok()
                    .map(|seconds| (seconds * 20.0) as i32);
            }
            (component::BLOCKS_ATTACKS, _) => out.1 = true,
            _ => {}
        }
    }
    out
}

/// The parts of a stack's `equippable` component (`Equippable`) the client
/// draws with.
#[derive(Clone, Debug, PartialEq)]
pub struct Equippable {
    /// `slot`: `EquipmentSlot`'s serialized name.
    pub slot: String,
    /// `assetId`: the equipment asset drawn when worn (`minecraft:iron`).
    pub asset_id: Option<String>,
    /// `cameraOverlay`: the texture drawn over the screen when worn
    /// (`minecraft:misc/pumpkinblur`).
    pub camera_overlay: Option<String>,
}

/// `stack.get(DataComponents.EQUIPPABLE)`: the item's own, replaced or removed
/// by the saved components (a command's, a save's), then by the server's patch.
pub fn equippable(stack: &ItemStack, items: &crate::items::Items) -> Option<Equippable> {
    let mut out = item_equippable(&stack.item, items);
    let Some(data) = stack.data() else {
        return out;
    };
    if data.other("!minecraft:equippable").is_some() {
        out = None;
    } else if let Some(e) = data.other("minecraft:equippable") {
        let string = |key: &str| match e.get(key) {
            Some(Tag::String(s)) => Some(s.to_string_lossy()),
            _ => None,
        };
        out = string("slot").map(|slot| Equippable {
            slot,
            asset_id: string("asset_id").map(namespaced),
            camera_overlay: string("camera_overlay").map(namespaced),
        });
    }
    let Some((added, removed)) = data
        .wire
        .patch()
        .and_then(|p| horizon_protocol::item::WirePatch::decode(p).ok())
    else {
        return out;
    };
    if removed.contains(&component::EQUIPPABLE) {
        out = None;
    }
    for (kind, c) in &added {
        if let (component::EQUIPPABLE, Component::Raw(bytes)) = (*kind, c) {
            out = decode_equippable(bytes);
        }
    }
    out
}

/// The `equippable` component `item`'s prototype has.
pub fn item_equippable(item: &str, items: &crate::items::Items) -> Option<Equippable> {
    let info = items.get(item)?;
    Some(Equippable {
        slot: info.equip_slot.clone()?,
        asset_id: info.equip_asset.clone(),
        camera_overlay: info.equip_camera_overlay.clone(),
    })
}

/// `Identifier.parse`: an id without a namespace is `minecraft`'s.
fn namespaced(id: String) -> String {
    if id.contains(':') {
        id
    } else {
        format!("minecraft:{id}")
    }
}

/// `Equippable.STREAM_CODEC` up to the camera overlay: the slot, the equip
/// sound, the asset id and the camera overlay.
fn decode_equippable(bytes: &[u8]) -> Option<Equippable> {
    let mut r = Reader::new(bytes);
    let slot = equipment_slot_name(r.varint().ok()?)?.to_owned();
    // SoundEvent.STREAM_CODEC (ByteBufCodecs.holder): a registry id + 1, or 0
    // then the direct event, its id and optional fixed range.
    if r.varint().ok()? == 0 {
        r.string(32767).ok()?;
        if r.bool().ok()? {
            r.f32().ok()?;
        }
    }
    let asset_id = if r.bool().ok()? {
        Some(r.string(32767).ok()?)
    } else {
        None
    };
    let camera_overlay = if r.bool().ok()? {
        Some(r.string(32767).ok()?)
    } else {
        None
    };
    Some(Equippable {
        slot,
        asset_id,
        camera_overlay,
    })
}

/// `EquipmentSlot.byId`'s serialized names.
fn equipment_slot_name(id: i32) -> Option<&'static str> {
    Some(match id {
        0 => "mainhand",
        1 => "feet",
        2 => "legs",
        3 => "chest",
        4 => "head",
        5 => "offhand",
        6 => "body",
        7 => "saddle",
        _ => return None,
    })
}

/// `DyeColor.byId`: an unknown id is white (`OutOfBoundsStrategy.ZERO`).
fn dye_name(id: i32) -> &'static str {
    usize::try_from(id)
        .ok()
        .and_then(|i| crate::block_entity_render::DYES.get(i))
        .map_or("white", |d| d.0)
}

fn item_name(builtin: &Builtin, id: i32) -> Arc<str> {
    Arc::from(
        builtin
            .get("minecraft:item")
            .and_then(|i| i.name(id))
            .unwrap_or("minecraft:air"),
    )
}

/// The item's patched components as vanilla's `components` compound.
fn components_tag(s: &Stack, builtin: &Builtin, synced: &Dynamic) -> Option<Tag> {
    let name = |id: i32| {
        builtin
            .get("minecraft:data_component_type")
            .and_then(|types| types.name(id))
            .or_else(|| {
                synced
                    .custom_components
                    .then(|| horizon_protocol::item::custom::name(id))
                    .flatten()
            })
    };
    let mut entries: Vec<(&str, Tag)> = Vec::new();
    for (kind, c) in &s.added {
        let Some(key) = name(*kind) else {
            continue;
        };
        let value = match c {
            // A server's custom armour names its own equipment asset.
            Component::Raw(_) if *kind == component::EQUIPPABLE => {
                let Some(e) = s.equippable() else {
                    continue;
                };
                const SLOTS: [&str; 8] = [
                    "mainhand", "feet", "legs", "chest", "head", "offhand", "body", "saddle",
                ];
                let slot = SLOTS.get(e.slot as usize).copied().unwrap_or("head");
                Tag::compound(
                    [("slot", Tag::String(slot.into()))]
                        .into_iter()
                        .chain(
                            e.asset
                                .map(|a| ("asset_id", Tag::String(a.as_str().into()))),
                        )
                        .chain(
                            e.overlay
                                .map(|o| ("camera_overlay", Tag::String(o.as_str().into()))),
                        ),
                )
            }
            // A plugin's item with a cooldown of its own (ClientboundCooldownPacket names it).
            Component::Raw(_) if *kind == component::USE_COOLDOWN => {
                let Some((seconds, group)) = s.use_cooldown() else {
                    continue;
                };
                Tag::compound(
                    [("seconds", Tag::Float(seconds.to_bits()))]
                        .into_iter()
                        .chain(group.map(|g| ("cooldown_group", Tag::String(g.as_str().into())))),
                )
            }
            // `ItemContainerContents`: a shulker box's items, for its tooltip.
            Component::Raw(bytes) if *kind == component::CONTAINER => {
                let Some(slots) = container_tag(bytes, builtin, synced) else {
                    continue;
                };
                slots
            }
            // `TypedEntityData`: a block item's block entity, which the op
            // warning and a spawner's tooltip read.
            Component::Raw(bytes) if *kind == component::BLOCK_ENTITY_DATA => {
                let Some(data) = block_entity_data_tag(bytes, builtin) else {
                    continue;
                };
                data
            }
            // `SignText`: a copied sign's text, which this client's own placement
            // puts on the sign it predicts (#8102).
            Component::Raw(bytes)
                if matches!(
                    *kind,
                    component::SIGN_TEXT_FRONT | component::SIGN_TEXT_BACK
                ) =>
            {
                let Some(text) = sign_text_tag(bytes) else {
                    continue;
                };
                text
            }
            Component::Raw(bytes) if *kind == component::KINETIC_WEAPON => {
                let Some(kinetic) = kinetic::decode(bytes, builtin) else {
                    continue;
                };
                kinetic
            }
            // `ItemAttributeModifiers`: what the stack grants where it is worn or
            // held, which its tooltip and its wearer's attributes read in place
            // of its item type's (`item_attributes`).
            Component::Raw(bytes) if *kind == component::ATTRIBUTE_MODIFIERS => {
                let Some(modifiers) = attribute_modifiers::decode(bytes, builtin) else {
                    continue;
                };
                modifiers
            }
            // `DeathProtection`: the effects a stack runs when it saves its
            // holder. The activation animation's hand lookup reads them, and
            // an item like an apple with the component keeps its own look
            // instead of a plain totem's (#12632).
            Component::Raw(bytes) if *kind == component::DEATH_PROTECTION => {
                let Some(protection) = death_protection_tag(bytes, builtin) else {
                    continue;
                };
                protection
            }
            // AdventureModePredicate: the blocks an adventure player may break
            // or place on, which this client matches as the server does.
            Component::Raw(bytes) if matches!(*kind, component::CAN_BREAK | CAN_PLACE_ON) => {
                let Some(predicate) = adventure_predicate_tag(bytes, builtin) else {
                    continue;
                };
                predicate
            }
            Component::TrimDirect { material, pattern } => {
                use horizon_protocol::item::TrimHolder;
                let material = match material {
                    TrimHolder::Id(id) => {
                        let Some(name) = synced.name("minecraft:trim_material", *id) else {
                            continue;
                        };
                        Tag::String(name.into())
                    }
                    TrimHolder::Direct(value) => Tag::compound([
                        ("palette_id", Tag::String(value.palette_id.as_str().into())),
                        ("description", value.description.clone()),
                    ]),
                };
                let pattern = match pattern {
                    TrimHolder::Id(id) => {
                        let Some(name) = synced.name("minecraft:trim_pattern", *id) else {
                            continue;
                        };
                        Tag::String(name.into())
                    }
                    TrimHolder::Direct(value) => Tag::compound([
                        ("asset_id", Tag::String(value.asset_id.as_str().into())),
                        ("description", value.description.clone()),
                        ("decal", Tag::Byte(i8::from(value.decal))),
                    ]),
                };
                Tag::compound([("material", material), ("pattern", pattern)])
            }
            // Read past, not decoded: the item keeps its prototype's value.
            Component::Raw(_) => continue,
            // Trim materials and patterns are synced registries, as enchantments are.
            Component::Trim { material, pattern } => {
                let (Some(material), Some(pattern)) = (
                    synced.name("minecraft:trim_material", *material),
                    synced.name("minecraft:trim_pattern", *pattern),
                ) else {
                    continue;
                };
                Tag::compound([
                    ("material", Tag::String(material.into())),
                    ("pattern", Tag::String(pattern.into())),
                ])
            }
            // Instruments are a synced registry: a goat horn names its own.
            Component::Instrument(id) => match synced.name("minecraft:instrument", *id) {
                Some(name) => Tag::String(name.into()),
                None => continue,
            },
            // BannerPatternLayers: each layer's pattern is a synced registry entry.
            Component::BannerPatterns(layers) => {
                let layers: Option<Vec<Tag>> = layers
                    .iter()
                    .map(|(pattern, color)| {
                        let pattern = synced.name("minecraft:banner_pattern", *pattern)?;
                        Some(Tag::compound([
                            ("pattern", Tag::String(pattern.into())),
                            ("color", Tag::String(dye_name(*color).into())),
                        ]))
                    })
                    .collect();
                let Some(layers) = layers else {
                    continue;
                };
                Tag::List(layers)
            }
            // `painting/variant`: a synced registry entry, as trims are.
            Component::PaintingVariant(id) => {
                let Some(name) = synced.name("minecraft:painting_variant", *id) else {
                    continue;
                };
                Tag::String(name.into())
            }
            // A shield's `base_color`: the dye's id.
            Component::Int(v) if *kind == component::BASE_COLOR => Tag::String(dye_name(*v).into()),
            Component::Int(v) if *kind == component::RARITY => {
                let rarity = ["common", "uncommon", "rare", "epic"];
                Tag::String(rarity.get(*v as usize).copied().unwrap_or("common").into())
            }
            Component::Int(v) => Tag::Int(*v),
            Component::Unit => Tag::Compound(Default::default()),
            Component::Bool(v) => Tag::Byte(i8::from(*v)),
            Component::Text(t) | Component::Nbt(t) => t.clone(),
            Component::Ident(v) => Tag::String(v.as_str().into()),
            Component::Lore(lines) => Tag::List(lines.clone()),
            Component::WritableBook { pages, .. } => Tag::compound([(
                "pages",
                Tag::List(
                    pages
                        .iter()
                        .map(|p| Tag::String(p.as_str().into()))
                        .collect(),
                ),
            )]),
            Component::WrittenBook(b) => Tag::compound([
                ("title", Tag::String(b.title.as_str().into())),
                ("author", Tag::String(b.author.as_str().into())),
                ("generation", Tag::Int(b.generation)),
                ("pages", Tag::List(b.pages.clone())),
                ("resolved", Tag::Byte(i8::from(b.resolved))),
            ]),
            Component::Fireworks { flight, explosions } => Tag::compound([
                ("flight_duration", Tag::Byte(*flight as i8)),
                (
                    "explosions",
                    Tag::List(explosions.iter().map(fireworks_tag).collect()),
                ),
            ]),
            Component::FireworkExplosion(e) => fireworks_tag(e),
            Component::LodestoneTracker { target, tracked } => {
                let mut entries = Vec::new();
                if let Some((dimension, pos)) = target {
                    entries.push((
                        "target",
                        Tag::compound([
                            ("dimension", Tag::String(dimension.as_str().into())),
                            ("pos", Tag::IntArray(pos.to_vec())),
                        ]),
                    ));
                }
                if !tracked {
                    entries.push(("tracked", Tag::Byte(0)));
                }
                Tag::compound(entries)
            }
            Component::Enchantments(list) => {
                // Enchantments are a synced (data-driven) registry: the
                // ids index the server's RegistryData, not the builtin
                // report, so a datapack enchantment names correctly.
                let levels = list.iter().filter_map(|(id, level)| {
                    let name = synced.name("minecraft:enchantment", *id)?;
                    Some((name, Tag::Int(*level)))
                });
                Tag::compound(levels)
            }
            Component::AttackRange(v) => Tag::compound([
                ("min_reach", Tag::Float(v[0].to_bits())),
                ("max_reach", Tag::Float(v[1].to_bits())),
                ("min_attack_momentum", Tag::Float(v[2].to_bits())),
                ("max_attack_momentum", Tag::Float(v[3].to_bits())),
                ("hitbox_margin", Tag::Float(v[4].to_bits())),
                ("mob_factor", Tag::Float(v[5].to_bits())),
            ]),
            Component::Profile(p) => profile_tag(p),
            // SuspiciousStewEffects' NBT: each effect by name and its duration.
            Component::StewEffects(list) => Tag::List(
                list.iter()
                    .filter_map(|(id, duration)| {
                        let name = builtin.get("minecraft:mob_effect")?.name(*id)?;
                        Some(Tag::compound([
                            ("id", Tag::String(name.into())),
                            ("duration", Tag::Int(*duration)),
                        ]))
                    })
                    .collect(),
            ),
            // PotionContents' NBT: the potion by name and the custom colour.
            Component::Potion { potion, color, .. } => {
                let potion = potion.and_then(|id| builtin.get("minecraft:potion")?.name(id));
                Tag::compound(
                    potion
                        .map(|name| ("potion", Tag::String(name.into())))
                        .into_iter()
                        .chain(color.map(|c| ("custom_color", Tag::Int(c)))),
                )
            }
            // ItemStackTemplate.CODEC: id, count and components.
            Component::Stacks(stacks) => Tag::List(
                stacks
                    .iter()
                    .map(|t| template_tag(t, builtin, synced))
                    .collect(),
            ),
            Component::CustomModelData {
                floats,
                flags,
                strings,
                colors,
            } => Tag::compound([
                (
                    "floats",
                    Tag::List(floats.iter().map(|f| Tag::Float(f.to_bits())).collect()),
                ),
                (
                    "flags",
                    Tag::List(flags.iter().map(|b| Tag::Byte(i8::from(*b))).collect()),
                ),
                (
                    "strings",
                    Tag::List(
                        strings
                            .iter()
                            .map(|s| Tag::String(s.as_str().into()))
                            .collect(),
                    ),
                ),
                (
                    "colors",
                    Tag::List(colors.iter().map(|c| Tag::Int(*c)).collect()),
                ),
            ]),
            Component::TooltipDisplay { hide, hidden } => {
                let hidden = hidden
                    .iter()
                    .filter_map(|id| Some(Tag::String(name(*id)?.into())));
                // As `OptionalFieldCodec`, the saved form leaves `hide_tooltip`
                // out when it is false; `decode_components` compares the raid
                // captain banner's tooltip against that form exactly.
                let mut entries = vec![("hidden_components", Tag::List(hidden.collect()))];
                if *hide {
                    entries.push(("hide_tooltip", Tag::Byte(1)));
                }
                Tag::compound(entries)
            }
        };
        entries.push((key, value));
    }
    let mut out = Tag::compound(entries);
    if let Tag::Compound(map) = &mut out {
        for id in &s.removed {
            // A removed `attribute_modifiers` grants nothing, not its item type's.
            if matches!(
                *id,
                component::MAX_STACK_SIZE
                    | component::KINETIC_WEAPON
                    | component::ATTRIBUTE_MODIFIERS
            ) && let Some(name) = name(*id)
            {
                map.insert(
                    format!("!{name}").as_str().into(),
                    Tag::Compound(Default::default()),
                );
            }
            // A removal the item's own prototype would otherwise provide:
            // `totem_of_undying[!death_protection]` must not keep protecting.
            if *id == component::DEATH_PROTECTION
                && let Some(name) = name(*id)
            {
                map.insert(
                    format!("!{name}").as_str().into(),
                    Tag::Compound(Default::default()),
                );
            }
            if synced.custom_components
                && let Some(name) = horizon_protocol::item::custom::name(*id)
            {
                map.insert(
                    format!("!{name}").as_str().into(),
                    Tag::Compound(Default::default()),
                );
            }
        }
    }
    Some(out)
}

/// An `ItemStackTemplate` as its NBT codec writes it: id, count and components.
fn template_tag(t: &Stack, builtin: &Builtin, synced: &Dynamic) -> Tag {
    let mut entries = vec![
        (
            "id",
            Tag::String(item_name(builtin, t.item).as_ref().into()),
        ),
        ("count", Tag::Int(t.count)),
    ];
    if let Some(c) = components_tag(t, builtin, synced) {
        entries.push(("components", c));
    }
    Tag::compound(entries)
}

/// `TypedEntityData.streamCodec` of a block entity: its type's registry id,
/// then its data without the id, which the saved component keeps.
fn block_entity_data_tag(bytes: &[u8], builtin: &Builtin) -> Option<Tag> {
    let mut r = Reader::new(bytes);
    let id = r.varint().ok()?;
    let kind = builtin.get("minecraft:block_entity_type")?.name(id)?;
    let Tag::Compound(mut data) = r.nbt().ok()? else {
        return None;
    };
    data.insert("id".into(), Tag::String(kind.into()));
    Some(Tag::Compound(data))
}

/// `DataComponents.CAN_PLACE_ON`'s registry id (26.3); `CAN_BREAK` follows it.
const CAN_PLACE_ON: i32 = 14;

/// `AdventureModePredicate.STREAM_CODEC` (a list of `BlockPredicate`s) as
/// `AdventureModePredicate.CODEC` saves it: one predicate, or a list of them
/// (`ExtraCodecs.compactListCodec`). Each keeps its `blocks` (a `#tag`, one
/// block id or a list), `state` and `nbt`; `DataComponentMatchers` are read
/// past (`BlockPredicate.matches(BlockInWorld)` does not test them), and a
/// predicate with exact components, whose values this side cannot read, gives
/// up on the whole component.
fn adventure_predicate_tag(bytes: &[u8], builtin: &Builtin) -> Option<Tag> {
    let blocks = builtin.get("minecraft:block")?;
    let mut r = Reader::new(bytes);
    let n = r.count(r.remaining()).ok()?;
    let mut predicates = Vec::with_capacity(n.min(64));
    for _ in 0..n {
        let mut p: Vec<(&str, Tag)> = Vec::new();
        // ByteBufCodecs.holderSet: 0 and a tag id, or the size plus one and the ids.
        if r.bool().ok()? {
            let set = match r.varint().ok()? {
                0 => Tag::String(format!("#{}", r.string(32767).ok()?).as_str().into()),
                size => {
                    let size = usize::try_from(size).ok()?.checked_sub(1)?;
                    if size > r.remaining() {
                        return None;
                    }
                    let mut ids = (0..size)
                        .map(|_| Some(Tag::String(blocks.name(r.varint().ok()?)?.into())))
                        .collect::<Option<Vec<_>>>()?;
                    if ids.len() == 1 {
                        ids.pop()?
                    } else {
                        Tag::List(ids)
                    }
                }
            };
            p.push(("blocks", set));
        }
        // StatePropertiesPredicate: each property an exact value, or a range.
        if r.bool().ok()? {
            let mut state: Vec<(String, Tag)> = Vec::new();
            for _ in 0..r.count(r.remaining()).ok()? {
                let name = r.string(32767).ok()?;
                let matcher = if r.bool().ok()? {
                    Tag::String(r.string(32767).ok()?.as_str().into())
                } else {
                    let mut range = Vec::new();
                    for bound in ["min", "max"] {
                        if r.bool().ok()? {
                            range.push((bound, Tag::String(r.string(32767).ok()?.as_str().into())));
                        }
                    }
                    Tag::compound(range)
                };
                state.push((name, matcher));
            }
            p.push((
                "state",
                Tag::compound(state.iter().map(|(k, v)| (k.as_str(), v.clone()))),
            ));
        }
        // NbtPredicate.STREAM_CODEC: a compound.
        if r.bool().ok()? {
            p.push(("nbt", r.nbt().ok()?));
        }
        // DataComponentExactPredicate: typed component values.
        if r.count(r.remaining()).ok()? != 0 {
            return None;
        }
        // DataComponentPredicate: a type id and the predicate as NBT.
        for _ in 0..r.count(r.remaining()).ok()? {
            r.bool().ok()?;
            r.varint().ok()?;
            r.nbt().ok()?;
        }
        predicates.push(Tag::compound(p));
    }
    if predicates.len() == 1 {
        predicates.pop()
    } else {
        Some(Tag::List(predicates))
    }
}

/// `SignText.STREAM_CODEC` as `SignText.CODEC` saves it: the four messages,
/// the filtered four when the server sent them, the dye colour and the glow.
fn sign_text_tag(bytes: &[u8]) -> Option<Tag> {
    let mut r = Reader::new(bytes);
    let lines = |r: &mut Reader| (0..4).map(|_| r.nbt().ok()).collect::<Option<Vec<_>>>();
    let mut text = vec![("messages", Tag::List(lines(&mut r)?))];
    if r.bool().ok()? {
        text.push(("filtered_messages", Tag::List(lines(&mut r)?)));
    }
    text.push(("color", Tag::String(dye_name(r.varint().ok()?).into())));
    text.push(("has_glowing_text", Tag::Byte(i8::from(r.bool().ok()?))));
    Some(Tag::compound(text))
}

/// How deep a `ConsumeEffect`'s hidden effects may nest: deeper than vanilla's
/// own effects ever go, shallow enough not to exhaust the stack on hostile bytes.
const MAX_EFFECT_NESTING: u32 = 32;

/// `DeathProtection.STREAM_CODEC` (component 36) as `DeathProtection.CODEC`
/// saves it: `death_effects` (absent when empty), each one a `ConsumeEffect` in
/// its codec's form. The activation animation's hand lookup reads this
/// (`game::totem`), so an item carrying the component is drawn as itself.
fn death_protection_tag(bytes: &[u8], builtin: &Builtin) -> Option<Tag> {
    let mut r = Reader::new(bytes);
    let n = r.count(r.remaining()).ok()?;
    let mut effects = Vec::with_capacity(n.min(64));
    for _ in 0..n {
        effects.push(consume_effect_tag(&mut r, builtin, 0)?);
    }
    (r.remaining() == 0).then_some(())?;
    Some(Tag::compound(if effects.is_empty() {
        Vec::new()
    } else {
        vec![("death_effects", Tag::List(effects))]
    }))
}

/// One `ConsumeEffect.STREAM_CODEC` as `ConsumeEffect.CODEC` saves it: a `type`
/// then that type's fields, with a field at its default left out.
fn consume_effect_tag(r: &mut Reader, builtin: &Builtin, depth: u32) -> Option<Tag> {
    if depth > MAX_EFFECT_NESTING {
        return None;
    }
    let mut fields: Vec<(&str, Tag)> = Vec::new();
    match r.varint().ok()? {
        // apply_effects: effects, probability.
        0 => {
            fields.push(("type", Tag::String("minecraft:apply_effects".into())));
            let n = r.count(r.remaining()).ok()?;
            let mut effects = Vec::with_capacity(n.min(64));
            for _ in 0..n {
                effects.push(mob_effect_tag(r, builtin, depth + 1)?);
            }
            fields.push(("effects", Tag::List(effects)));
            let probability = r.f32().ok()?;
            if probability.to_bits() != 1.0f32.to_bits() {
                fields.push(("probability", Tag::Float(probability.to_bits())));
            }
        }
        // remove_effects: a mob effect holder set, a tag or its entries.
        1 => {
            fields.push(("type", Tag::String("minecraft:remove_effects".into())));
            fields.push((
                "effects",
                holder_set_tag(r, "minecraft:mob_effect", builtin)?,
            ));
        }
        2 => fields.push(("type", Tag::String("minecraft:clear_all_effects".into()))),
        // teleport_randomly: diameter, directional particles.
        3 => {
            fields.push(("type", Tag::String("minecraft:teleport_randomly".into())));
            let diameter = r.f32().ok()?;
            if diameter.to_bits() != 16.0f32.to_bits() {
                fields.push(("diameter", Tag::Float(diameter.to_bits())));
            }
            if !r.bool().ok()? {
                fields.push(("directional_particles", Tag::Byte(0)));
            }
        }
        // play_sound.
        4 => {
            fields.push(("type", Tag::String("minecraft:play_sound".into())));
            fields.push(("sound", sound_tag(r, builtin)?));
        }
        _ => return None,
    }
    Some(Tag::compound(fields))
}

/// `MobEffectInstance.CODEC`: the effect's identifier and its details.
fn mob_effect_tag(r: &mut Reader, builtin: &Builtin, depth: u32) -> Option<Tag> {
    let id = builtin
        .get("minecraft:mob_effect")?
        .name(r.varint().ok()?)?;
    let Tag::Compound(mut details) = mob_effect_details_tag(r, depth)? else {
        return None;
    };
    details.insert("id".into(), Tag::String(id.into()));
    Some(Tag::Compound(details))
}

/// `MobEffectInstance.Details.MAP_CODEC`: amplifier, duration, ambient,
/// show_particles, show_icon, then the hidden effect's details.
fn mob_effect_details_tag(r: &mut Reader, depth: u32) -> Option<Tag> {
    if depth > MAX_EFFECT_NESTING {
        return None;
    }
    let amplifier = r.varint().ok()?;
    let duration = r.varint().ok()?;
    let ambient = r.bool().ok()?;
    let particles = r.bool().ok()?;
    let icon = r.bool().ok()?;
    let mut fields: Vec<(&str, Tag)> = Vec::new();
    if amplifier != 0 {
        fields.push(("amplifier", Tag::Byte(amplifier as i8)));
    }
    if duration != 0 {
        fields.push(("duration", Tag::Int(duration)));
    }
    if ambient {
        fields.push(("ambient", Tag::Byte(1)));
    }
    if !particles {
        fields.push(("show_particles", Tag::Byte(0)));
    }
    fields.push(("show_icon", Tag::Byte(i8::from(icon))));
    if r.bool().ok()? {
        fields.push(("hidden_effect", mob_effect_details_tag(r, depth + 1)?));
    }
    Some(Tag::compound(fields))
}

/// `ByteBufCodecs.holderSet`: a tag as `#name`, a lone entry as itself, else a
/// list of names.
fn holder_set_tag(r: &mut Reader, registry: &str, builtin: &Builtin) -> Option<Tag> {
    match r.varint().ok()? {
        0 => Some(Tag::String(
            format!("#{}", r.string(32767).ok()?).as_str().into(),
        )),
        n => {
            let count = usize::try_from(n.checked_sub(1)?).ok()?;
            if count > r.remaining() {
                return None;
            }
            let ids = builtin.get(registry)?;
            let mut names: Vec<Tag> = Vec::with_capacity(count);
            for _ in 0..count {
                names.push(Tag::String(ids.name(r.varint().ok()?)?.into()));
            }
            Some(match names.len() {
                1 => names.pop()?,
                _ => Tag::List(names),
            })
        }
    }
}

/// `SoundEvent.STREAM_CODEC` as `SoundEvent.CODEC` saves it: the event's name,
/// or the event itself (`sound_id` and an optional `range`).
fn sound_tag(r: &mut Reader, builtin: &Builtin) -> Option<Tag> {
    match r.varint().ok()? {
        0 => {
            let id = r.string(32767).ok()?;
            let mut fields: Vec<(&str, Tag)> = vec![("sound_id", Tag::String(id.as_str().into()))];
            if r.bool().ok()? {
                fields.push(("range", Tag::Float(r.f32().ok()?.to_bits())));
            }
            Some(Tag::compound(fields))
        }
        n => Some(Tag::String(
            builtin
                .get("minecraft:sound_event")?
                .name(n.checked_sub(1)?)?
                .into(),
        )),
    }
}

/// `ItemContainerContents.STREAM_CODEC`, one optional template per slot, as
/// the saved `container` lists the slots that hold one.
fn container_tag(bytes: &[u8], builtin: &Builtin, synced: &Dynamic) -> Option<Tag> {
    let mut r = Reader::new(bytes);
    let mut slots = Vec::new();
    for slot in 0..r.count(256).ok()? {
        if r.bool().ok()? {
            let stack = Template::read(&mut r).ok()?;
            slots.push(Tag::compound([
                ("slot", Tag::Int(slot as i32)),
                ("item", template_tag(&stack, builtin, synced)),
            ]));
        }
    }
    Some(Tag::List(slots))
}

/// A wire `FireworkExplosion` as vanilla's NBT codec writes it
/// (`FireworkExplosion.Shape`'s BY_ID order).
fn fireworks_tag(e: &horizon_protocol::item::FireworkExplosion) -> Tag {
    const SHAPES: [&str; 5] = ["small_ball", "large_ball", "star", "creeper", "burst"];
    let ints = |c: &[i32]| Tag::List(c.iter().map(|c| Tag::Int(*c)).collect());
    Tag::compound([
        (
            "shape",
            Tag::String(
                SHAPES
                    .get(e.shape.max(0) as usize)
                    .copied()
                    .unwrap_or("small_ball")
                    .into(),
            ),
        ),
        ("colors", ints(&e.colors)),
        ("fade_colors", ints(&e.fade)),
        ("has_trail", Tag::Byte(i8::from(e.trail))),
        ("has_twinkle", Tag::Byte(i8::from(e.twinkle))),
    ])
}

/// A `minecraft:profile` component as the item data JSON the model reads.
fn profile_tag(p: &Profile) -> Tag {
    let properties = p
        .properties
        .iter()
        .map(|(name, value, signature)| {
            let mut entries: Vec<(&'static str, Tag)> = vec![
                ("name", Tag::String(name.as_str().into())),
                ("value", Tag::String(value.as_str().into())),
            ];
            if let Some(signature) = signature {
                entries.push(("signature", Tag::String(signature.as_str().into())));
            }
            Tag::compound(entries)
        })
        .collect::<Vec<_>>();
    let mut entries: Vec<(&'static str, Tag)> = Vec::new();
    if let Some(name) = &p.name {
        entries.push(("name", Tag::String(name.as_str().into())));
    }
    if let Some(id) = p.id {
        entries.push((
            "id",
            Tag::IntArray(vec![
                (id >> 96) as i32,
                (id >> 64) as i32,
                (id >> 32) as i32,
                id as i32,
            ]),
        ));
    }
    entries.push(("properties", Tag::List(properties)));
    Tag::compound(entries)
}

#[cfg(test)]
mod tests {
    use super::*;
    use horizon_protocol::registry::Ids;

    /// A chestplate a server made a glider: its patch adds `glider` and an
    /// `equippable` for the chest, or takes `glider` away again.
    #[test]
    fn a_servers_patch_makes_any_item_a_glider() {
        let with_patch = |patch: &[u8]| {
            let mut stack = ItemStack::new("minecraft:diamond_chestplate", 1);
            stack.data_mut().wire =
                crate::item_data::Wire::new(stack.clone(), Arc::from(patch.to_vec()));
            stack
        };
        // Equippable: slot 3 (chest), a sound reference, no asset, overlay or
        // allowed entities, its five flags, the shearing sound.
        let equippable = [3, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1];
        let mut adds = vec![
            2,
            0,
            component::GLIDER as u8,
            0,
            component::EQUIPPABLE as u8,
        ];
        adds.push(equippable.len() as u8);
        adds.extend(equippable);
        assert_eq!(
            glider_and_slot(&with_patch(&adds), false, Some("head".into())),
            (true, Some("chest".into()))
        );
        let removes = [0, 1, component::GLIDER as u8];
        assert_eq!(
            glider_and_slot(&with_patch(&removes), true, Some("chest".into())),
            (false, Some("chest".into()))
        );
        // No data: the item's own.
        let plain = ItemStack::new("minecraft:elytra", 1);
        assert_eq!(
            glider_and_slot(&plain, true, Some("chest".into())),
            (true, Some("chest".into()))
        );
    }

    /// A command's chestplate (`/give @s diamond_chestplate[glider={},
    /// equippable={slot:"chest"}]`) keeps both as saved components.
    #[test]
    fn saved_components_make_any_item_a_glider() {
        let mut stack = ItemStack::new("minecraft:diamond_chestplate", 1);
        stack.data_mut().other = vec![
            ("minecraft:glider".into(), Tag::Compound(Default::default())),
            (
                "minecraft:equippable".into(),
                Tag::compound([("slot", Tag::String("chest".into()))]),
            ),
        ];
        assert_eq!(
            glider_and_slot(&stack, false, Some("chest".into())),
            (true, Some("chest".into()))
        );
        stack.data_mut().other = vec![(
            "!minecraft:equippable".into(),
            Tag::Compound(Default::default()),
        )];
        assert_eq!(glider_and_slot(&stack, true, Some("chest".into())).1, None);
    }

    #[test]
    fn merchant_water_cost_survives_the_offer_packet() {
        use horizon_protocol::{
            buf::{Codec, Reader, Writer},
            packets::play::{NetOffer, Offers},
        };
        let mut components = vec![String::new(); component::POTION_CONTENTS as usize + 1];
        components[component::POTION_CONTENTS as usize] = "minecraft:potion_contents".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".into(),
                    Ids::from_names(vec!["minecraft:potion".into(), "minecraft:emerald".into()]),
                ),
                (
                    "minecraft:potion".into(),
                    Ids::from_names(vec!["minecraft:water".into()]),
                ),
                (
                    "minecraft:data_component_type".into(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic::default();
        let water = ItemStack::new("minecraft:potion", 1).with_potion("minecraft:water");
        let wire = crate::lan::guest::stack_to_network(
            |name| builtin.get("minecraft:item").unwrap().id(name).unwrap(),
            |registry, name| builtin.get(registry)?.id(name),
            &Some(water.clone()),
        )
        .unwrap();
        let offers = vec![NetOffer {
            cost_a: wire.into(),
            result: Stack::new(1, 1),
            cost_b: Some(Stack::new(1, 2).into()),
            out_of_stock: false,
            uses: 0,
            max_uses: 2,
            xp: 0,
            special_price: 0,
            price_multiplier: 0.05,
            demand: 0,
        }];
        let mut w = Writer::new();
        Offers::write(&offers, &mut w);
        let mut r = Reader::new(&w.data);
        let decoded = Offers::read(&mut r).unwrap();
        assert_eq!(r.remaining(), 0);
        let cost = crate::merchant::ItemCost {
            stack: from_network(&decoded[0].cost_a.clone().into(), &builtin, &dynamic),
        };
        assert_eq!(cost.stack, water);
        assert_eq!(cost.stack.potion(), Some("minecraft:water"));
        let authoritative = crate::merchant::ItemCost {
            stack: water.clone(),
        };
        for payment in [
            water,
            ItemStack::new("minecraft:potion", 1).with_potion("minecraft:swiftness"),
            ItemStack::new("minecraft:potion", 1),
        ] {
            assert_eq!(cost.test(&payment), authoritative.test(&payment));
        }
        assert!(cost.test(&ItemStack::new("minecraft:potion", 1).with_potion("minecraft:water")));
        assert!(
            !cost.test(&ItemStack::new("minecraft:potion", 1).with_potion("minecraft:swiftness"))
        );
        let emerald = crate::merchant::ItemCost {
            stack: from_network(
                &decoded[0].cost_b.clone().unwrap().into(),
                &builtin,
                &dynamic,
            ),
        };
        assert!(emerald.test(&ItemStack::new("minecraft:emerald", 2)));
    }

    /// A bundle's contents cross the wire, so a server's client can draw
    /// its tooltip (BundleContents' stream codec: a list of templates).
    #[test]
    fn a_bundle_keeps_its_contents_across_the_wire() {
        let mut components = vec![String::new(); 60];
        components[component::BUNDLE_CONTENTS as usize] = "minecraft:bundle_contents".into();
        let items = ["minecraft:air", "minecraft:bundle", "minecraft:stone"];
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(items.iter().map(|s| s.to_string()).collect()),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic {
            registries: Default::default(),
            ..Default::default()
        };
        let mut bundle = ItemStack::new("minecraft:bundle", 1);
        bundle.data_mut().bundle_contents = vec![ItemStack::new("minecraft:stone", 32)];
        let wire = crate::lan::guest::stack_to_network(
            |name| items.iter().position(|i| *i == name).unwrap_or(0) as i32,
            |_, _| None,
            &Some(bundle),
        )
        .unwrap();
        let back = from_network(&wire, &builtin, &dynamic);
        let contents = &back.data().expect("components").bundle_contents;
        assert_eq!(contents.len(), 1);
        assert_eq!(
            (&*contents[0].item, contents[0].count),
            ("minecraft:stone", 32)
        );
    }

    /// `custom_model_data` and `item_model` reach the client, whose item
    /// model reads them (#4916): single player's window gets its stacks this way.
    #[test]
    fn model_components_cross_the_wire() {
        let mut components = vec![String::new(); 60];
        components[component::ITEM_MODEL as usize] = "minecraft:item_model".into();
        components[component::CUSTOM_MODEL_DATA as usize] = "minecraft:custom_model_data".into();
        let items = ["minecraft:air", "minecraft:stick"];
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(items.iter().map(|s| s.to_string()).collect()),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let given = crate::item_data::command_components(
            "[item_model='minecraft:emerald',custom_model_data={floats:[0.5f],flags:[1b],\
             strings:['gold'],colors:[16711680,[0.0f,1.0f,0.0f]]}]",
        )
        .unwrap();
        let (damage, extra) = crate::item_data::decode_components(Some(&given));
        let stick = ItemStack {
            damage,
            extra,
            ..ItemStack::new("minecraft:stick", 1)
        };
        let wire = crate::lan::guest::stack_to_network(
            |name| items.iter().position(|i| *i == name).unwrap_or(0) as i32,
            |_, _| None,
            &Some(stick),
        )
        .unwrap();
        let back = from_network(&wire, &builtin, &Dynamic::default());
        let data = back.data().expect("components");
        assert_eq!(
            crate::save::text(data.other("minecraft:item_model")).as_deref(),
            Some("minecraft:emerald")
        );
        let cmd = data
            .other("minecraft:custom_model_data")
            .expect("custom_model_data");
        let list = |key: &str| match cmd.get(key) {
            Some(Tag::List(l)) => l.clone(),
            other => panic!("{key}: {other:?}"),
        };
        assert_eq!(list("floats"), [Tag::Float(0.5f32.to_bits())]);
        assert_eq!(list("flags"), [Tag::Byte(1)]);
        assert_eq!(list("strings"), [Tag::String("gold".into())]);
        // The float triple arrives as the opaque int vanilla's codec makes of it.
        assert_eq!(
            list("colors"),
            [Tag::Int(16711680), Tag::Int(0xFF00FF00u32 as i32)]
        );
    }

    /// Both effective kinetic replacements and removals reach the client through
    /// the inventory stream, including fields that do not affect the pose.
    #[test]
    fn kinetic_patches_survive_inventory_bytes() {
        use horizon_protocol::{buf::Writer, item::Slot, registry::SyncedNames};
        let mut components = vec![String::new(); component::KINETIC_WEAPON as usize + 1];
        components[component::KINETIC_WEAPON as usize] = "minecraft:kinetic_weapon".into();
        let mut sounds = vec![String::new(); 703];
        sounds[702] = "minecraft:entity.generic.eat".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".into(),
                    Ids::from_names(vec!["minecraft:air".into(), "minecraft:iron_spear".into()]),
                ),
                (
                    "minecraft:data_component_type".into(),
                    Ids::from_names(components),
                ),
                ("minecraft:sound_event".into(), Ids::from_names(sounds)),
            ]
            .into(),
        };
        // Payloads and component hashes from the real 26.3 KineticWeapon codec.
        for (patch, payload, hash) in [
            ("{}", "0a00000000000000003f8000000000", -982207288),
            (
                "{contact_cooldown_ticks:7,delay_ticks:40.0d,dismount_conditions:{max_duration_ticks:200.0f,min_speed:14.0f},knockback_conditions:{max_duration_ticks:400,min_relative_speed:5.0f},damage_conditions:{max_duration_ticks:600},forward_movement:0.5f,damage_multiplier:2.0f,sound:'minecraft:entity.generic.eat',hit_sound:{sound_id:'test:hit',range:12.0f}}",
                "072801c80141600000000000000190030000000040a0000001d80400000000000000003f0000004000000001bf05010008746573743a6869740141400000",
                -2132767252,
            ),
            (
                "{delay_ticks:40,sound:'entity.generic.eat'}",
                "0a28000000000000003f80000001bf0500",
                211783960,
            ),
            (
                "{delay_ticks:40,sound:{sound_id:'entity.generic.eat'}}",
                "0a28000000000000003f80000001001c6d696e6563726166743a656e746974792e67656e657269632e6561740000",
                -607516834,
            ),
            (
                "{delay_ticks:40,sound:{sound_id:'minecraft:entity.generic.eat',range:'oops'}}",
                "0a28000000000000003f80000001001c6d696e6563726166743a656e746974792e67656e657269632e6561740000",
                -607516834,
            ),
            (
                "{delay_ticks:40,hit_sound:'entity.generic.eat'}",
                "0a28000000000000003f8000000001bf05",
                -1337610829,
            ),
            (
                "{delay_ticks:40,hit_sound:{sound_id:'entity.generic.eat'}}",
                "0a28000000000000003f8000000001001c6d696e6563726166743a656e746974792e67656e657269632e65617400",
                -1544992499,
            ),
            (
                "{delay_ticks:40,hit_sound:{sound_id:'minecraft:entity.generic.eat',range:'oops'}}",
                "0a28000000000000003f8000000001001c6d696e6563726166743a656e746974792e67656e657269632e65617400",
                -1544992499,
            ),
        ] {
            let component = horizon_core::nbt::parse_snbt(patch).unwrap().0;
            for removed in [false, true] {
                let key = if removed {
                    "!minecraft:kinetic_weapon"
                } else {
                    "minecraft:kinetic_weapon"
                };
                let (_, extra) = crate::item_data::decode_components(Some(&Tag::compound([(
                    key,
                    component.clone(),
                )])));
                let source = ItemStack {
                    extra,
                    ..ItemStack::new("minecraft:iron_spear", 1)
                };
                let sent = crate::lan::guest::stack_to_network(
                    |_| 1,
                    |registry, name| builtin.get(registry)?.id(name),
                    &Some(source),
                );
                let mut w = Writer::new();
                Slot::write(&sent, &mut w);
                let mut r = Reader::new(&w.data);
                let received = Slot::read(&mut r).unwrap().unwrap();
                assert_eq!(r.remaining(), 0);
                let back = from_network(&received, &builtin, &Dynamic::default());
                let value = back.data().unwrap().other(key).unwrap();
                if removed {
                    assert!(received.removed.contains(&component::KINETIC_WEAPON));
                } else {
                    let ticks = |key| horizon_world::datafix::dynamic::as_int(value.get(key), -1);
                    assert_eq!(ticks("delay_ticks"), if patch == "{}" { 0 } else { 40 });
                    let kinetic = received.component(component::KINETIC_WEAPON).unwrap();
                    let Component::Raw(bytes) = kinetic else {
                        panic!("kinetic stream payload")
                    };
                    let hex: String = bytes.iter().map(|b| format!("{b:02x}")).collect();
                    assert_eq!(hex, payload);
                    let dynamic = Dynamic::default();
                    let names = SyncedNames {
                        builtin: &builtin,
                        dynamic: &dynamic,
                    };
                    assert_eq!(kinetic.hash(component::KINETIC_WEAPON, &names), Some(hash));
                    let full = patch.starts_with("{contact_cooldown_ticks");
                    assert_eq!(ticks("contact_cooldown_ticks"), if full { 7 } else { 10 });
                    if full {
                        assert_eq!(
                            value
                                .get("dismount_conditions")
                                .unwrap()
                                .get("max_duration_ticks"),
                            Some(&Tag::Int(200))
                        );
                        assert_eq!(
                            value
                                .get("knockback_conditions")
                                .unwrap()
                                .get("min_relative_speed"),
                            Some(&Tag::Float(5.0f32.to_bits()))
                        );
                        assert_eq!(
                            value
                                .get("damage_conditions")
                                .unwrap()
                                .get("max_duration_ticks"),
                            Some(&Tag::Int(600))
                        );
                        assert_eq!(value.get("sound"), component.get("sound"));
                        assert_eq!(value.get("hit_sound"), component.get("hit_sound"));
                        assert_eq!(
                            value.get("forward_movement"),
                            component.get("forward_movement")
                        );
                        assert_eq!(
                            value.get("damage_multiplier"),
                            component.get("damage_multiplier")
                        );
                    }
                    // Re-encoding the decoded saved component must reproduce the
                    // actual stream bytes, including every non-pose field.
                    let sent_again = crate::lan::guest::stack_to_network(
                        |_| 1,
                        |registry, name| builtin.get(registry)?.id(name),
                        &Some(back),
                    );
                    let mut again = Writer::new();
                    Slot::write(&sent_again, &mut again);
                    assert_eq!(again.data, w.data);
                }
            }
        }
    }

    /// An unbreakable damaged stack must keep both components through inventory
    /// sync, including the integrated server's window (#5721).
    #[test]
    fn unbreakable_survives_inventory_sync() {
        use horizon_protocol::buf::{Codec, Reader, Writer};
        use horizon_protocol::item::Slot;
        let mut components = vec![String::new(); component::UNBREAKABLE as usize + 1];
        components[component::DAMAGE as usize] = "minecraft:damage".into();
        components[component::UNBREAKABLE as usize] = "minecraft:unbreakable".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".into(),
                    Ids::from_names(vec!["minecraft:air".into(), "minecraft:diamond_hoe".into()]),
                ),
                (
                    "minecraft:data_component_type".into(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        for unbreakable in [false, true] {
            let mut hoe = ItemStack::new("minecraft:diamond_hoe", 1);
            hoe.damage = 58;
            let marker = Tag::Compound(Default::default());
            if unbreakable {
                hoe.data_mut()
                    .set_other("minecraft:unbreakable", Some(marker.clone()));
            }
            let sent = crate::lan::guest::stack_to_network(|_| 1, |_, _| None, &Some(hoe));
            let mut w = Writer::new();
            Slot::write(&sent, &mut w);
            let mut r = Reader::new(&w.data);
            let received = Slot::read(&mut r).unwrap().unwrap();
            assert_eq!(r.remaining(), 0);
            assert_eq!(
                received.component(component::UNBREAKABLE),
                unbreakable.then_some(&Component::Unit)
            );
            let back = from_network(&received, &builtin, &Dynamic::default());
            assert_eq!(
                (&*back.item, back.count, back.damage),
                ("minecraft:diamond_hoe", 1, 58)
            );
            assert_eq!(
                back.data().and_then(|d| d.other("minecraft:unbreakable")),
                unbreakable.then_some(&marker)
            );
        }
    }

    /// An ominous bottle's `ominous_bottle_amplifier` reaches the client
    /// through the packet's bytes, so its tooltip names the Bad Omen level.
    #[test]
    fn an_ominous_bottle_keeps_its_amplifier_across_the_wire() {
        use horizon_protocol::buf::{Codec, Reader, Writer};
        use horizon_protocol::item::Slot;
        let mut components = vec![String::new(); 80];
        components[component::OMINOUS_BOTTLE_AMPLIFIER as usize] =
            "minecraft:ominous_bottle_amplifier".into();
        let items = ["minecraft:air", "minecraft:ominous_bottle"];
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(items.iter().map(|s| s.to_string()).collect()),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic {
            registries: Default::default(),
            ..Default::default()
        };
        for amplifier in [None, Some(0), Some(3)] {
            let mut bottle = ItemStack::new("minecraft:ominous_bottle", 1);
            if let Some(a) = amplifier {
                bottle.data_mut().ominous_amplifier = Some(a);
            }
            let wire = crate::lan::guest::stack_to_network(
                |name| items.iter().position(|i| *i == name).unwrap_or(0) as i32,
                |_, _| None,
                &Some(bottle),
            );
            let mut w = Writer::new();
            Slot::write(&wire, &mut w);
            let mut r = Reader::new(&w.data);
            let read = Slot::read(&mut r).unwrap().unwrap();
            assert_eq!(r.remaining(), 0);
            let back = from_network(&read, &builtin, &dynamic);
            assert_eq!(
                back.data().and_then(|d| d.ominous_amplifier),
                amplifier,
                "{amplifier:?}"
            );
        }
    }

    #[test]
    fn direct_trim_uses_actual_model_on_both_sides_without_cached_wire() {
        let source = horizon_core::nbt::parse_snbt(r#"{id:"minecraft:diamond_chestplate",count:1,components:{"minecraft:trim":{material:{palette_id:"minecraft:gold",description:"Inline material"},pattern:{asset_id:"minecraft:coast",description:"Inline pattern",decal:0b}},"minecraft:custom_data":{keep:284}}}"#).unwrap().0;
        let modeled = crate::save::item_from_nbt(&source).unwrap();
        let network =
            crate::lan::guest::stack_to_network(|_| 1, |_, _| None, &Some(modeled.clone()))
                .unwrap();
        assert!(matches!(
            network.component(component::TRIM),
            Some(Component::TrimDirect { .. })
        ));
        let mut writer = horizon_protocol::buf::Writer::new();
        horizon_protocol::item::Slot::write(&Some(network), &mut writer);
        let mut reader = Reader::new(&writer.data);
        let decoded = horizon_protocol::item::Slot::read(&mut reader)
            .unwrap()
            .unwrap();
        assert_eq!(reader.remaining(), 0);
        let mut names = vec![String::new(); component::TRIM as usize + 1];
        names[component::TRIM as usize] = "minecraft:trim".into();
        names[component::CUSTOM_DATA as usize] = "minecraft:custom_data".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".into(),
                    Ids::from_names(vec![
                        "minecraft:air".into(),
                        "minecraft:diamond_chestplate".into(),
                    ]),
                ),
                (
                    "minecraft:data_component_type".into(),
                    Ids::from_names(names),
                ),
            ]
            .into(),
        };
        let mut back = from_network(&decoded, &builtin, &Dynamic::default());
        back.data_mut().wire = Default::default();
        assert_eq!(back, modeled);
        assert_eq!(crate::save::item_to_nbt(&back), source);
        let again = crate::lan::guest::stack_to_network(|_| 1, |_, _| None, &Some(back)).unwrap();
        assert!(matches!(
            again.component(component::TRIM),
            Some(Component::TrimDirect { .. })
        ));
    }

    /// What a creative client sends (`stack_to_network`) comes back whole on
    /// the server: damage, both enchantment lists, repair cost, name, trim,
    /// potion and stew effects.
    #[test]
    fn a_creative_stack_keeps_its_components_across_the_wire() {
        let mut components = vec![String::new(); 60];
        for (id, name) in [
            (component::MAX_DAMAGE, "minecraft:max_damage"),
            (component::DAMAGE, "minecraft:damage"),
            (component::CUSTOM_NAME, "minecraft:custom_name"),
            (component::ITEM_NAME, "minecraft:item_name"),
            (component::ENCHANTMENTS, "minecraft:enchantments"),
            (component::POTION_CONTENTS, "minecraft:potion_contents"),
            (component::REPAIR_COST, "minecraft:repair_cost"),
            (
                component::STORED_ENCHANTMENTS,
                "minecraft:stored_enchantments",
            ),
            (component::TRIM, "minecraft:trim"),
            (
                component::SUSPICIOUS_STEW_EFFECTS,
                "minecraft:suspicious_stew_effects",
            ),
        ] {
            components[id as usize] = name.to_owned();
        }
        let names = |n: &[&str]| n.iter().map(|s| s.to_string()).collect::<Vec<_>>();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(names(&[
                        "minecraft:air",
                        "minecraft:diamond_chestplate",
                        "minecraft:splash_potion",
                        "minecraft:suspicious_stew",
                    ])),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
                (
                    "minecraft:potion".to_owned(),
                    Ids::from_names(names(&["minecraft:water", "minecraft:swiftness"])),
                ),
                (
                    "minecraft:mob_effect".to_owned(),
                    Ids::from_names(names(&["minecraft:speed", "minecraft:fire_resistance"])),
                ),
            ]
            .into(),
        };
        let synced = |n: &[&str]| n.iter().map(|s| (s.to_string(), None)).collect::<Vec<_>>();
        let dynamic = Dynamic {
            registries: [
                (
                    "minecraft:enchantment".to_owned(),
                    synced(&["minecraft:protection", "minecraft:sharpness"]),
                ),
                (
                    "minecraft:trim_material".to_owned(),
                    synced(&["minecraft:gold"]),
                ),
                (
                    "minecraft:trim_pattern".to_owned(),
                    synced(&["minecraft:sentry"]),
                ),
            ]
            .into(),
            ..Default::default()
        };
        let mut stack = ItemStack::new("minecraft:diamond_chestplate", 1);
        stack.damage = 5;
        stack.enchant("minecraft:protection", 4);
        let d = stack.data_mut();
        d.set_other("minecraft:max_damage", Some(Tag::Int(500)));
        d.stored_enchantments
            .push((Arc::from("minecraft:sharpness"), 2));
        d.repair_cost = 9;
        d.custom_name = Some(Tag::String("Keeper".into()));
        // A translatable item name reaches the client as the same component.
        let item_name = Tag::compound([("translate", Tag::String("filled_map.monument".into()))]);
        d.other
            .push(("minecraft:item_name".into(), item_name.clone()));
        d.trim = Some(("minecraft:gold".into(), "minecraft:sentry".into()));
        let id = |registry: &str, name: &str| {
            builtin
                .get(registry)
                .and_then(|ids| ids.id(name))
                .or_else(|| dynamic.id(registry, name))
        };
        let wire = crate::lan::guest::stack_to_network(
            |name| {
                builtin
                    .get("minecraft:item")
                    .and_then(|i| i.id(name))
                    .unwrap_or(0)
            },
            id,
            &Some(stack.clone()),
        )
        .unwrap();
        let back = from_network(&wire, &builtin, &dynamic);
        assert_eq!(back.item, stack.item);
        assert_eq!(back.damage, 5);
        let d = back.data().expect("components");
        assert_eq!(d.other("minecraft:max_damage"), Some(&Tag::Int(500)));
        assert_eq!(d.enchantments, vec![(Arc::from("minecraft:protection"), 4)]);
        assert_eq!(
            d.stored_enchantments,
            vec![(Arc::from("minecraft:sharpness"), 2)]
        );
        assert_eq!(d.repair_cost, 9);
        assert_eq!(d.custom_name_plain().as_deref(), Some("Keeper"));
        assert_eq!(d.other("minecraft:item_name"), Some(&item_name));
        assert_eq!(
            d.trim,
            Some(("minecraft:gold".into(), "minecraft:sentry".into()))
        );
        // PotionContents: the potion is a built-in registry, as a hub's
        // `SyncData::id` treats it, so the id has to come from there.
        let potion = ItemStack::new("minecraft:splash_potion", 1).with_potion("swiftness");
        let wire = crate::lan::guest::stack_to_network(
            |name| id("minecraft:item", name).unwrap_or(0),
            id,
            &Some(potion),
        )
        .unwrap();
        assert_eq!(
            from_network(&wire, &builtin, &dynamic).potion(),
            Some("minecraft:swiftness")
        );
        // SuspiciousStewEffects, as a creative tab's stew has them: without
        // them the server's stew gives no effect when eaten (#3137).
        let mut stew = ItemStack::new("minecraft:suspicious_stew", 1);
        stew.data_mut()
            .stew_effects
            .push((Arc::from("minecraft:fire_resistance"), 60));
        let wire = crate::lan::guest::stack_to_network(
            |name| id("minecraft:item", name).unwrap_or(0),
            id,
            &Some(stew),
        )
        .unwrap();
        let back = from_network(&wire, &builtin, &dynamic);
        assert_eq!(
            back.data().map(|d| d.stew_effects.clone()),
            Some(vec![(Arc::from("minecraft:fire_resistance"), 60)])
        );
    }

    /// The raid captain's banner keeps the name, rarity and hidden pattern
    /// layers `Raid.getBannerComponentPatch` gives it, so a guest's copy reads
    /// as the ominous banner rather than a white one (#12530).
    #[test]
    fn an_ominous_banner_keeps_its_name_across_the_wire() {
        use horizon_protocol::buf::{Codec, Reader, Writer};
        use horizon_protocol::item::Slot;
        let mut components = vec![String::new(); component::BANNER_PATTERNS as usize + 1];
        for (id, name) in [
            (component::ITEM_NAME, "minecraft:item_name"),
            (component::RARITY, "minecraft:rarity"),
            (component::TOOLTIP_DISPLAY, "minecraft:tooltip_display"),
            (component::BANNER_PATTERNS, "minecraft:banner_patterns"),
        ] {
            components[id as usize] = name.to_owned();
        }
        let items = ["minecraft:air", "minecraft:white_banner"];
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(items.iter().map(|s| s.to_string()).collect()),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let layers = crate::item_data::OMINOUS_LAYERS;
        let dynamic = Dynamic {
            registries: [(
                "minecraft:banner_pattern".to_owned(),
                layers
                    .iter()
                    .map(|(pattern, _)| (format!("minecraft:{pattern}"), None))
                    .collect(),
            )]
            .into(),
            ..Default::default()
        };
        let id = |registry: &str, name: &str| {
            builtin
                .get(registry)
                .and_then(|ids| ids.id(name))
                .or_else(|| dynamic.id(registry, name))
        };
        let wire = crate::lan::guest::stack_to_network(
            |name| id("minecraft:item", name).unwrap_or(0),
            id,
            &Some(crate::mobs::raider::ominous_banner()),
        );
        // Read it as a peer does: the slot codec, then the components.
        let mut w = Writer::new();
        Slot::write(&wire, &mut w);
        let mut r = Reader::new(&w.data);
        let read = Slot::read(&mut r).unwrap().unwrap();
        assert_eq!(r.remaining(), 0);
        let back = from_network(&read, &builtin, &dynamic);
        let d = back.data().expect("components");
        assert!(d.ominous_banner, "the name reads as the ominous banner");
        assert_eq!(d.banner_patterns.len(), layers.len());
        // The modelled parts are not duplicated into `other`.
        assert_eq!(d.other("minecraft:item_name"), None);
        assert_eq!(d.other("minecraft:rarity"), None);
        assert_eq!(d.other("minecraft:tooltip_display"), None);
    }

    /// A painting's `painting/variant` (a `painting_variant` holder, id 109)
    /// crosses the wire both ways: a server's creative slot gets the variant
    /// its client picked, and a client's tooltip names the server's.
    #[test]
    fn a_painting_keeps_its_variant_across_the_wire() {
        use horizon_protocol::buf::{Codec, Reader, Writer};
        use horizon_protocol::item::Slot;
        let mut components = vec![String::new(); 110];
        components[109] = "minecraft:painting/variant".into();
        let items = ["minecraft:air", "minecraft:painting"];
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(items.iter().map(|s| s.to_string()).collect()),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let variants = ["minecraft:alban", "minecraft:kebab"];
        let dynamic = Dynamic {
            registries: [(
                "minecraft:painting_variant".to_owned(),
                variants.iter().map(|v| (v.to_string(), None)).collect(),
            )]
            .into(),
            ..Default::default()
        };
        // ItemStack.OPTIONAL_STREAM_CODEC: count 1, the painting, one added
        // component (109: the reference to kebab, its id plus one), none removed.
        let vanilla = [1u8, 1, 1, 0, 109, 2];
        let stack = Slot::read(&mut Reader::new(&vanilla)).unwrap().unwrap();
        let back = from_network(&stack, &builtin, &dynamic);
        let variant = |s: &ItemStack| {
            s.data()
                .and_then(|d| d.other("minecraft:painting/variant"))
                .cloned()
        };
        assert_eq!(variant(&back), Some(Tag::String("minecraft:kebab".into())));
        let mut alban = ItemStack::new("minecraft:painting", 1);
        alban.data_mut().set_other(
            "minecraft:painting/variant",
            Some(Tag::String("minecraft:alban".into())),
        );
        let wire = crate::lan::guest::stack_to_network(
            |name| items.iter().position(|i| *i == name).unwrap_or(0) as i32,
            |registry, name| dynamic.id(registry, name),
            &Some(alban.clone()),
        );
        let mut w = Writer::new();
        Slot::write(&wire, &mut w);
        assert_eq!(w.data, [1, 1, 1, 0, 109, 1]);
        let wire = Slot::read(&mut Reader::new(&w.data)).unwrap().unwrap();
        assert_eq!(
            variant(&from_network(&wire, &builtin, &dynamic)),
            variant(&alban)
        );
    }

    /// A stack's own `attribute_modifiers` (id 16) cross the wire both ways: a
    /// server's patch reaches the client's stack as the list its attributes and
    /// tooltip read in place of the item type's, a patch that removes the
    /// component leaves it none, and a host sends both on as they came.
    #[test]
    fn a_stacks_own_attribute_modifiers_cross_the_wire() {
        use horizon_items::item_data::ModifierRow;
        use horizon_protocol::buf::{Codec, Reader, Writer};
        use horizon_protocol::item::Slot;
        let names = |n: &[&str]| n.iter().map(|s| s.to_string()).collect::<Vec<_>>();
        let mut components = vec![String::new(); 17];
        components[component::ATTRIBUTE_MODIFIERS as usize] =
            "minecraft:attribute_modifiers".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(names(&["minecraft:air", "minecraft:diamond_helmet"])),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
                (
                    "minecraft:attribute".to_owned(),
                    Ids::from_names(names(&[
                        "minecraft:armor",
                        "minecraft:armor_toughness",
                        "minecraft:luck",
                    ])),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic::default();
        let id = |registry: &str, name: &str| builtin.get(registry)?.id(name);
        let sent_on = |stack: ItemStack| {
            let wire = crate::lan::guest::stack_to_network(
                |name| id("minecraft:item", name).unwrap_or(0),
                id,
                &Some(stack),
            );
            let mut w = Writer::new();
            Slot::write(&wire, &mut w);
            w.data
        };
        let helmet = [ModifierRow::new(
            "minecraft:armor",
            "minecraft:armor.helmet",
            3.0,
            "add_value",
            "head",
        )];
        // ItemStack.OPTIONAL_STREAM_CODEC: one diamond helmet, one component
        // added: one entry, luck (id 2), `test:charm`, 1.5, add_value (0), the
        // head slot group (7) and the default display (0).
        let mut vanilla = Writer::new();
        for v in [1, 1, 1, 0, component::ATTRIBUTE_MODIFIERS, 1, 2] {
            vanilla.varint(v);
        }
        vanilla.string("test:charm");
        vanilla.f64(1.5);
        for v in [0, 7, 0] {
            vanilla.varint(v);
        }
        let stack = Slot::read(&mut Reader::new(&vanilla.data))
            .unwrap()
            .unwrap();
        let back = from_network(&stack, &builtin, &dynamic);
        assert_eq!(
            &*back.default_attribute_modifiers_or(&helmet),
            [ModifierRow::new(
                "minecraft:luck",
                "test:charm",
                1.5,
                "add_value",
                "head"
            )]
        );
        assert_eq!(sent_on(back), vanilla.data);
        // The same helmet with the component removed: no modifiers at all.
        let removed = [1, 1, 0, 1, component::ATTRIBUTE_MODIFIERS as u8];
        let stack = Slot::read(&mut Reader::new(&removed)).unwrap().unwrap();
        let back = from_network(&stack, &builtin, &dynamic);
        assert!(back.default_attribute_modifiers_or(&helmet).is_empty());
        assert_eq!(sent_on(back), removed);
    }

    /// A sign picked with its data (`SignBlockEntity.collectImplicitComponents`)
    /// keeps its text across the wire both ways: `sign_text_front` and
    /// `sign_text_back` (ids 118 and 119, `SignText.STREAM_CODEC`) reach the
    /// client's stack, whose own placement puts the text on the sign (#8102).
    #[test]
    fn a_signs_text_crosses_the_wire() {
        use horizon_protocol::buf::{Reader, Writer};
        use horizon_protocol::item::Slot;
        let mut components = vec![String::new(); 120];
        components[118] = "minecraft:sign_text_front".into();
        components[119] = "minecraft:sign_text_back".into();
        let items = ["minecraft:air", "minecraft:oak_sign"];
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".to_owned(),
                    Ids::from_names(items.iter().map(|s| s.to_string()).collect()),
                ),
                (
                    "minecraft:data_component_type".to_owned(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic::default();
        let line = |s: &str| Tag::String(s.into());
        let text = |lines: [&str; 4], color: &str, glowing: i8| {
            Tag::compound([
                ("messages", Tag::List(lines.map(line).to_vec())),
                ("color", Tag::String(color.into())),
                ("has_glowing_text", Tag::Byte(glowing)),
            ])
        };
        let front = text(["Line one", "Line two", "", "Line four"], "black", 0);
        let back = text(["", "back", "", ""], "red", 1);
        let mut sign = ItemStack::new("minecraft:oak_sign", 1);
        sign.data_mut()
            .set_other("minecraft:sign_text_front", Some(front.clone()));
        sign.data_mut()
            .set_other("minecraft:sign_text_back", Some(back.clone()));
        let wire = crate::lan::guest::stack_to_network(
            |name| items.iter().position(|i| *i == name).unwrap_or(0) as i32,
            |_, _| None,
            &Some(sign),
        );
        let mut w = Writer::new();
        Slot::write(&wire, &mut w);
        let wire = Slot::read(&mut Reader::new(&w.data)).unwrap().unwrap();
        let client = from_network(&wire, &builtin, &dynamic);
        let data = client.data().expect("the sign's components");
        assert_eq!(data.other("minecraft:sign_text_front"), Some(&front));
        assert_eq!(data.other("minecraft:sign_text_back"), Some(&back));
    }

    /// `minecraft:custom_data` and `minecraft:custom_model_data` are part of
    /// vanilla's DataComponentPatch, so they must cross integrated-server/LAN
    /// inventory sync like any other component (item models read them back:
    /// `item_model.rs`'s `custom_data_at`).
    #[test]
    fn custom_data_and_custom_model_data_survive_lan_sync() {
        use horizon_protocol::buf::{Reader, Writer};
        use horizon_protocol::item::Slot;
        let mut components = vec![String::new(); component::CUSTOM_MODEL_DATA as usize + 1];
        components[component::CUSTOM_DATA as usize] = "minecraft:custom_data".into();
        components[component::CUSTOM_MODEL_DATA as usize] = "minecraft:custom_model_data".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".into(),
                    Ids::from_names(vec!["minecraft:air".into(), "minecraft:stick".into()]),
                ),
                (
                    "minecraft:data_component_type".into(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic::default();
        let mut item = ItemStack::new("minecraft:stick", 1);
        item.data_mut().set_other(
            "minecraft:custom_data",
            Some(Tag::compound([(
                "mymod_material",
                Tag::String("ruby".into()),
            )])),
        );
        item.data_mut().set_other(
            "minecraft:custom_model_data",
            Some(Tag::compound([
                ("colors", Tag::List(vec![Tag::Int(0x00a0_a0a0)])),
                ("flags", Tag::List(vec![Tag::Byte(1)])),
                ("floats", Tag::List(vec![Tag::Float(1.0f32.to_bits())])),
                ("strings", Tag::List(vec![Tag::String("mymod:ruby".into())])),
            ])),
        );
        let wire = crate::lan::guest::stack_to_network(
            |name| builtin.get("minecraft:item").unwrap().id(name).unwrap(),
            |_, _| None,
            &Some(item.clone()),
        );
        let mut w = Writer::new();
        Slot::write(&wire, &mut w);
        let received = Slot::read(&mut Reader::new(&w.data)).unwrap().unwrap();
        let back = from_network(&received, &builtin, &dynamic);
        let other = |s: &ItemStack, id: &str| s.data().and_then(|d| d.other(id)).cloned();
        assert_eq!(
            other(&back, "minecraft:custom_data"),
            other(&item, "minecraft:custom_data")
        );
        assert_eq!(
            other(&back, "minecraft:custom_model_data"),
            other(&item, "minecraft:custom_model_data")
        );
    }

    #[test]
    fn rarity_survives_lan_sync_and_enchantment_upgrade() {
        use horizon_protocol::buf::{Reader, Writer};
        use horizon_protocol::item::Slot;
        use horizon_protocol::registry::Ids;
        let mut components = vec![String::new(); component::RARITY as usize + 1];
        components[component::RARITY as usize] = "minecraft:rarity".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".into(),
                    Ids::from_names(vec!["minecraft:air".into(), "minecraft:stick".into()]),
                ),
                (
                    "minecraft:data_component_type".into(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic::default();
        let mut item = ItemStack::new("minecraft:stick", 1);
        item.data_mut()
            .set_other("minecraft:rarity", Some(Tag::String("epic".into())));
        item.enchant("minecraft:aqua_affinity", 1);

        let wire = crate::lan::guest::stack_to_network(
            |name| builtin.get("minecraft:item").unwrap().id(name).unwrap(),
            |_, _| None,
            &Some(item.clone()),
        );
        let mut w = Writer::new();
        Slot::write(&wire, &mut w);
        let received = Slot::read(&mut Reader::new(&w.data)).unwrap().unwrap();
        assert_eq!(
            received.component(component::RARITY),
            Some(&Component::Int(3))
        );

        let back = from_network(&received, &builtin, &dynamic);
        assert_eq!(
            back.data().and_then(|d| d.other("minecraft:rarity")),
            Some(&Tag::String("epic".into()))
        );
        assert_eq!(crate::item_tooltip::rarity(&back, "common"), "epic");
    }

    /// A cobblestone stack of 20 whose own limit is 16, plus a custom-data
    /// marker, comes back with the same count, limit and marker. Removing the
    /// component is a `!minecraft:max_stack_size` patch.
    #[test]
    fn a_stack_keeps_its_max_stack_size_across_the_wire() {
        use horizon_protocol::buf::{Reader, Writer};
        use horizon_protocol::item::Slot;
        let mut components = vec![String::new(); 2];
        components[component::CUSTOM_DATA as usize] = "minecraft:custom_data".into();
        components[component::MAX_STACK_SIZE as usize] = "minecraft:max_stack_size".into();
        let builtin = Builtin {
            registries: [
                (
                    "minecraft:item".into(),
                    Ids::from_names(vec!["minecraft:air".into(), "minecraft:cobblestone".into()]),
                ),
                (
                    "minecraft:data_component_type".into(),
                    Ids::from_names(components),
                ),
            ]
            .into(),
        };
        let dynamic = Dynamic::default();
        let marker = Tag::compound([("marker", Tag::Byte(1))]);
        let mut item = ItemStack::new("minecraft:cobblestone", 20);
        item.data_mut()
            .set_other("minecraft:max_stack_size", Some(Tag::Int(16)));
        item.data_mut()
            .set_other("minecraft:custom_data", Some(marker.clone()));
        let wire = crate::lan::guest::stack_to_network(
            |name| builtin.get("minecraft:item").unwrap().id(name).unwrap(),
            |_, _| None,
            &Some(item),
        )
        .unwrap();
        let mut w = Writer::new();
        Slot::write(&Some(wire), &mut w);
        let received = Slot::read(&mut Reader::new(&w.data)).unwrap().unwrap();
        assert_eq!(received.count, 20);
        assert_eq!(
            received.component(component::MAX_STACK_SIZE),
            Some(&Component::Int(16))
        );
        let back = from_network(&received, &builtin, &dynamic);
        assert_eq!(back.count, 20);
        assert_eq!(
            back.data()
                .and_then(|d| d.other("minecraft:max_stack_size")),
            Some(&Tag::Int(16))
        );
        assert_eq!(
            back.data().and_then(|d| d.other("minecraft:custom_data")),
            Some(&marker)
        );

        let mut cleared = ItemStack::new("minecraft:cobblestone", 1);
        cleared.data_mut().set_other(
            "!minecraft:max_stack_size",
            Some(Tag::Compound(Default::default())),
        );
        let wire = crate::lan::guest::stack_to_network(
            |name| builtin.get("minecraft:item").unwrap().id(name).unwrap(),
            |_, _| None,
            &Some(cleared),
        )
        .unwrap();
        assert!(wire.removed.contains(&component::MAX_STACK_SIZE));
        let back = from_network(&wire, &builtin, &dynamic);
        assert!(
            back.data()
                .is_some_and(|d| d.other("!minecraft:max_stack_size").is_some())
        );
    }
}
